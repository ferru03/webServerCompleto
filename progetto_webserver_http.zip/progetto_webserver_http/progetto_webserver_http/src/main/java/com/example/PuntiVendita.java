package com.example;

import java.util.ArrayList;

public class PuntiVendita {
    private int size;
    private ArrayList<PuntoVendita> puntiVendita;

    public PuntiVendita(){

    }

    public int getSize() {
        return size;
    }

    public ArrayList<PuntoVendita> getPuntiVendita() {
        return puntiVendita;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public void setPuntiVendita(ArrayList<PuntoVendita> puntiVendita) {
        this.puntiVendita = puntiVendita;
    }
}
