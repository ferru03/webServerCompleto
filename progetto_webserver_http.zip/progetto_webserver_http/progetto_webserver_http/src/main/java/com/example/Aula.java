package com.example;

public class Aula {
    private String nome;
    private int numeroDiBanchi;

    public Aula(){

    }

    public String getNome() {
        return nome;
    }

    public int getNumeroDiBanchi() {
        return numeroDiBanchi;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setNumeroDiBanchi(int numeroDiBanchi) {
        this.numeroDiBanchi = numeroDiBanchi;
    }
}
